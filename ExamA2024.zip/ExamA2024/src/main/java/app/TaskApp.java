package app;

import conf.SettingsManager;
import task.TaskList;

public class TaskApp {
    public static void main(String[] args) {
        SettingsManager sm = SettingsManager.getInstance();
        TaskList taskList = new TaskList();
        TaskUI taskUI = new TaskUI(sm);
        TaskController taskController = new TaskController(taskList, taskUI);
        
        // Start the TaskList thread
        new Thread(taskList).start();
        
        taskUI.setVisible(true);
    }
}