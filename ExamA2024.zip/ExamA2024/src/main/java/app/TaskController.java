package app;

import task.Task;
import task.TaskList;
import task.TaskListObserver;
import task.TaskBuilder;
import util.Helper;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class TaskController implements ActionListener, TaskListObserver {
    private TaskList model;
    private TaskUI view;

    public TaskController(TaskList model, TaskUI view) {
        this.model = model;
        this.view = view;
        this.view.getAddButton().addActionListener(this);
        this.view.getDoneButton().addActionListener(this);
        this.model.addObserver(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getAddButton()) {
            String title = view.getNewTaskTitle();
            String description = view.getNewTaskDescription();
            if (title != null && !title.isEmpty()) {
                Task newTask = new TaskBuilder()
                    .setId(model.getNextTaskNumber())
                    .setTitle(title)
                    .setDescription(description)
                    .setPriority(Helper.assignPriority())
                    .setCreationDate(Helper.getCurrentDateTime())
                    .setCompleted(false)
                    .build();
                model.addTask(newTask);
            }
        } else if (e.getSource() == view.getDoneButton()) {
            int selectedIndex = view.getSelectedTaskIndex();
            if (selectedIndex != -1) {
                model.setTaskCompleted(selectedIndex);
            }
        }
    }

    @Override
    public void updateTasks(List<Task> tasks) {
        view.showTasks(tasks);
    }
}