package servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import dao.DAOFactory;

@WebListener
public class AppListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("The application started");
        ServletContext context = sce.getServletContext();
        String path = context.getRealPath("/WEB-INF/tasks");
        DAOFactory.TASKS_DIRECTORY = path;
        System.out.println("tasks folder set to: " + path);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("The application stopped");
    }
}