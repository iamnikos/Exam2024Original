package task;

import java.time.LocalDateTime;

public class TaskBuilder {
    private int id;
    private String title;
    private String description;
    private int priority;
    private LocalDateTime creationDate;
    private boolean completed;

    public TaskBuilder setId(int id) {
        this.id = id;
        return this;
    }

    public TaskBuilder setTitle(String title) {
        this.title = title;
        return this;
    }

    public TaskBuilder setDescription(String description) {
        this.description = description;
        return this;
    }

    public TaskBuilder setPriority(int priority) {
        this.priority = priority;
        return this;
    }

    public TaskBuilder setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    public TaskBuilder setCompleted(boolean completed) {
        this.completed = completed;
        return this;
    }

    public Task build() {
        return new Task(id, title, description, priority, creationDate);
    }
}