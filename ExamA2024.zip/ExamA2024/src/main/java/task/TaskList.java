package task;

import java.util.ArrayList;
import java.util.List;
import dao.DAOFactory;

public class TaskList implements Runnable {
    private int taskCount = 0;
    private List<Task> tasks;
    private List<TaskListObserver> observers;
    private boolean running;

    public TaskList() {
        this.tasks = new ArrayList<>();
        this.observers = new ArrayList<>();
        this.running = true;
        retrieveTasks();
    }

    private void retrieveTasks() {
        tasks = DAOFactory.getTaskDAO().getAllTasks();
        taskCount = tasks.size();
        notifyObservers();
    }

    public List<Task> getTasks() {
        return new ArrayList<>(tasks);
    }

    public int getNextTaskNumber() {
        return ++taskCount;
    }

    public synchronized void addTask(Task task) {
        tasks.add(task);
        DAOFactory.getTaskDAO().saveTask(task);
        notifyObservers();
        notify(); // Notify the thread to check for completed tasks
    }

    public synchronized void deleteTask(Task task) {
        tasks.remove(task);
        DAOFactory.getTaskDAO().deleteTask(task);
        notifyObservers();
    }

    public synchronized void setTaskCompleted(int index) {
        if (index >= 0 && index < tasks.size()) {
            Task task = tasks.get(index);
            task.setCompleted();
            DAOFactory.getTaskDAO().saveTask(task);
            notifyObservers();
            notify(); // Notify the thread to check for completed tasks
        }
    }

    public void addObserver(TaskListObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(TaskListObserver observer) {
        observers.remove(observer);
    }

    private void notifyObservers() {
        for (TaskListObserver observer : observers) {
            observer.updateTasks(getTasks());
        }
    }

    @Override
    public void run() {
        while (running) {
            synchronized (this) {
                try {
                    wait(); // Wait for notification
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }

                if (tasks.size() > 5) {
                    tasks.removeIf(Task::isCompleted);
                    notifyObservers();
                }
            }
        }
    }

    public void stopThread() {
        running = false;
        synchronized (this) {
            notify();
        }
    }
}