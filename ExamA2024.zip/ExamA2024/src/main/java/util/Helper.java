package util;

import java.time.LocalDateTime;
import java.util.Random;

public class Helper {
    public static int assignPriority() {
        Random random = new Random();
        return random.nextInt(10) + 1;
    }

    public static LocalDateTime getCurrentDateTime() {
        return LocalDateTime.now();
    }
}